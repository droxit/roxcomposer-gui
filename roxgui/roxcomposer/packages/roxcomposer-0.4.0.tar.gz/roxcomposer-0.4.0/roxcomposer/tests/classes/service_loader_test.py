class DummyClass:
    def __init__(self, args):
        self.args = args

    def get_args(self):
        return self.args
